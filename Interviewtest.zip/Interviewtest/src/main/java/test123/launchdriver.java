package test123;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;



public class launchdriver {


	  public static void main(String[] args) throws IOException {
		
	
		URL urlcheck= new URL("https://www.google.co.in/");
		
		HttpsURLConnection connection = (HttpsURLConnection) urlcheck.openConnection();
		connection.setRequestMethod("GET");
		int response = connection.getResponseCode();
		
		System.out.println(response);
	}
	
}
	
