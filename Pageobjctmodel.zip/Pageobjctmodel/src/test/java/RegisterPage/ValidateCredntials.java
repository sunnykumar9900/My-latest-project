package RegisterPage;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.LoginPage;

public class ValidateCredntials extends  BaseClass{

	   
	 public ValidateCredntials()
	 {
		 
		 super();
	 }
	
	@BeforeMethod
	public void initiabrowser() throws IOException
	{
		
		
		
		LoginPage broserobject = new LoginPage(); 
		  broserobject.Enterapplication();
		
	}
	
   @Test
   public void test()
   {
	  
	   System.out.println("yes");
	 
   }
	
   @AfterMethod
   public void after()
   {
	   
	   System.out.println("yes1");
   }
	
	
}
