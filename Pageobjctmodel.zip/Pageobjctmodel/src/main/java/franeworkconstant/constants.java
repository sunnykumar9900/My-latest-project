package franeworkconstant;

public interface constants {

	
	
}
