package Logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import BaseClass.BaseClass;

public class  LoggerConfiguration
{

	public static Logger loggerConfiguration ()
	
	{
		
		Logger log = Logger.getLogger(BaseClass.class);
		PropertyConfigurator.configure("C:\\Sunny_Work_Space\\Pageobjctmodel\\LogFile\\log4j.properties");
		return log;
	}
	
	
}
