package BaseClass;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import org.testng.annotations.Test;

import Listeners.ListnerImplementation;
import Logger.LoggerConfiguration;
import PathInitialzer.Pathreader;
import PropertiesFilereader.PropertiesfileReader;

import net.bytebuddy.agent.builder.AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.SinglePass;

public class BaseClass {

	
	public static WebDriver driver;
	
	
	 
	
	   
	 public  BaseClass()  {
	  
	try {
		String brower = PropertiesfileReader.propertiesfile("browser");
	      if(brower.contentEquals("chrome"))
	  {
		  System.setProperty(PropertiesfileReader.propertiesfile("driver"),PropertiesfileReader.propertiesfile("driverpath"));
		  ChromeOptions options = new ChromeOptions();
		  options.addArguments("start-maximized");
		  LoggerConfiguration.loggerConfiguration().info("Window Maximzed");
		  driver = new ChromeDriver(options);
		  LoggerConfiguration.loggerConfiguration().info("Chromedriver Launched successfully");
	
		  EventFiringWebDriver eventRecorder = new EventFiringWebDriver(driver);
		  ListnerImplementation lst = new ListnerImplementation();
		  eventRecorder.register(lst);
		 eventRecorder.get(Pathreader.getmapdata().get("URL").toString());
		
		
	  }
	  
	  else if(brower.contentEquals("edge"))
	  {
		  System.setProperty(PropertiesfileReader.propertiesfile("driver"),PropertiesfileReader.propertiesfile("driverpath"));
		  WebDriver driver = new ChromeDriver(); 
		  driver.manage().window().maximize();
		  driver.get(Pathreader.getmapdata().get("URL").toString());
		  
	  }
	  } catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
	  
	  }
	
	  

    
	 }
	 
          
          
}

