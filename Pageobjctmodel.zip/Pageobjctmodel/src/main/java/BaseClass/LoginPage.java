package BaseClass;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import PropertiesFilereader.PropertiesfileReader;



public class LoginPage extends BaseClass {
	  
	public void  Enterapplication() throws IOException
	{
		
		 
		driver.findElement(By.name("username")).sendKeys("abcd");
		driver.findElement(By.name("password")).sendKeys("abcd1");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
	}
	
	
	
}
