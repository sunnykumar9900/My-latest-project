package PathInitialzer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class Pathreader {

	  public static Map<String, String> getmapdata() throws IOException
	  {
		 
		  Path currentRelativePath = Paths.get("");
		  String s = currentRelativePath.toAbsolutePath().toString() + "\\Excelfiles" + "\\DBDetails.xlsx";
		
		  Map<String , String> value1 = new HashMap<String, String>();
		  
		 
		  File file = new File(s);
		   FileInputStream stream = new FileInputStream(file);
			XSSFWorkbook book = new XSSFWorkbook(stream);
			XSSFSheet sheet = book.getSheet("Console_Scale");
		   int row = sheet.getLastRowNum();
		   
		   for(int i=0;i<=row;i++)
		   {
			   Row sheetrow = sheet.getRow(i);
			   Cell keyvalue = sheetrow.getCell(0);
			   String keyvalue1 = keyvalue.getStringCellValue().trim();
			   
			   Cell valueofkey = sheetrow.getCell(1);
			   String valueofkey1 =   valueofkey.getStringCellValue().trim();
			   value1.put(keyvalue1, valueofkey1);
			  
		   }
		return value1;
		  
	  }
	
	
	
	
	
}
