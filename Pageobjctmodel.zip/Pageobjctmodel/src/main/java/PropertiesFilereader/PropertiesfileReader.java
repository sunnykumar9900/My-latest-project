package PropertiesFilereader;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class PropertiesfileReader {
	

	

	public static String  propertiesfile(String data) throws IOException 
	
	{
		                                               
		Path currentRelativePath = Paths.get("");
		String s = currentRelativePath.toAbsolutePath().toString() + "\\Propertiesfile" + "\\Driverdetails.properties";
		
		File fie = new File(s);
		FileInputStream stream = new FileInputStream(fie);
		Properties prop = new Properties();
		prop.load(stream);
	     String value =   prop.get(data).toString();
		return value;
	    
		
	}
	
	
}
